# Bot perfecto - Ruby
# Uso: export ANTHROPIC_API_KEY="tu-llave-nueva"
#      ruby bot.rb
# La llave nunca va escrita en el código ni en el chat.

require 'net/http'
require 'json'
require 'uri'

api_key = ENV['ANTHROPIC_API_KEY']
if api_key.nil? || api_key.empty?
  warn 'Falta ANTHROPIC_API_KEY. Ponla así:'
  warn 'export ANTHROPIC_API_KEY="tu-llave"'
  exit 1
end

payload = {
  model: 'claude-opus-5-5',
  max_tokens: 1024,
  system: [
    {
      type: 'text',
      text: 'You are an AI assistant tasked with analyzing literary themes.',
      cache_control: { type: 'ephemeral' }
    }
  ],
  messages: [
    {
      role: 'user',
      content: "Analyze the major themes in 'Pride and Prejudice' by Jane Austen."
    }
  ]
}

uri = URI('https://api.anthropic.com/v1/messages')
http = Net::HTTP.new(uri.host, uri.port)
http.use_ssl = true

request = Net::HTTP::Post.new(uri)
request['x-api-key'] = api_key
request['anthropic-version'] = '2023-06-01'
request['content-type'] = 'application/json'
request.body = payload.to_json

response = http.request(request)

unless response.code == '200'
  warn "La API respondió #{response.code}:"
  warn response.body
  exit 1
end

data = JSON.parse(response.body)
text = (data['content'] || []).select { |b| b['type'] == 'text' }.map { |b| b['text'] }.join

puts text
puts
puts "Uso: #{data['usage'].to_json}"

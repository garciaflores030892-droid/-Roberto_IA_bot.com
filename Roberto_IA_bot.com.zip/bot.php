<?php
// Bot perfecto - PHP
// Uso: export ANTHROPIC_API_KEY="tu-llave-nueva"
//      php bot.php
// La llave nunca va escrita en el código ni en el chat.

$apiKey = getenv('ANTHROPIC_API_KEY');
if (!$apiKey) {
    fwrite(STDERR, "Falta ANTHROPIC_API_KEY. Ponla así:\n");
    fwrite(STDERR, "export ANTHROPIC_API_KEY=\"tu-llave\"\n");
    exit(1);
}

$payload = [
    'model' => 'claude-opus-5-5',
    'max_tokens' => 1024,
    'system' => [
        [
            'type' => 'text',
            'text' => 'You are an AI assistant tasked with analyzing literary themes.',
            'cache_control' => ['type' => 'ephemeral'],
        ],
    ],
    'messages' => [
        [
            'role' => 'user',
            'content' => "Analyze the major themes in 'Pride and Prejudice' by Jane Austen.",
        ],
    ],
];

$ch = curl_init('https://api.anthropic.com/v1/messages');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'x-api-key: ' . $apiKey,
    'anthropic-version: 2023-06-01',
    'content-type: application/json',
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));

$raw = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
if ($raw === false) {
    fwrite(STDERR, 'Error de red: ' . curl_error($ch) . "\n");
    exit(1);
}
curl_close($ch);

$data = json_decode($raw, true);
if ($httpCode !== 200) {
    fwrite(STDERR, "La API respondió $httpCode:\n$raw\n");
    exit(1);
}

$text = '';
foreach ($data['content'] ?? [] as $block) {
    if (($block['type'] ?? '') === 'text') {
        $text .= $block['text'];
    }
}

echo $text . "\n\n";
echo 'Uso: ' . json_encode($data['usage'] ?? []) . "\n";

#!/usr/bin/env python3
# parche.py - parchea RG.html para que use el servidor RG en 127.0.0.1:8787
# Uso: python parche.py RG.html
#      python parche.py ~/storage/downloads/RG.html
import sys
import shutil

def main():
    if len(sys.argv) < 2:
        print("Uso: python parche.py RG.html")
        return
    p = sys.argv[1]
    try:
        with open(p, "r", encoding="utf-8", errors="ignore") as f:
            txt = f.read()
    except FileNotFoundError:
        print(f"No existe el archivo: {p}")
        return
    # Respaldo
    shutil.copy(p, p + ".bak")
    nuevo = "var RG_SERVER = 'http://127.0.0.1:8787/';"
    if "RG_SERVER" in txt:
        # Reemplaza las formas vacias mas comunes
        txt2 = txt.replace("var RG_SERVER = '';", nuevo)
        txt2 = txt2.replace('var RG_SERVER = "";', nuevo)
        txt2 = txt2.replace("var RG_SERVER = ''", nuevo)
        txt2 = txt2.replace('var RG_SERVER = ""', nuevo)
        if txt2 == txt:
            print("RG_SERVER ya estaba en el archivo, no se cambio nada.")
            print("Revisa la linea con: grep RG_SERVER " + p)
            return
        txt = txt2
        print("Parche aplicado: RG_SERVER cambiado a http://127.0.0.1:8787/")
    else:
        # No existe la variable, la agregamos antes de </body>
        etiqueta = "<script>" + nuevo + "</script>"
        if "</body>" in txt:
            txt = txt.replace("</body>", etiqueta + "\n</body>", 1)
        elif "</head>" in txt:
            txt = txt.replace("</head>", etiqueta + "\n</head>", 1)
        else:
            txt = txt + "\n" + etiqueta + "\n"
        print("Parche aplicado: se agrego RG_SERVER = http://127.0.0.1:8787/")
    with open(p, "w", encoding="utf-8") as f:
        f.write(txt)
    print("Respaldo guardado en: " + p + ".bak")
    print("Listo, compa.")

if __name__ == "__main__":
    main()

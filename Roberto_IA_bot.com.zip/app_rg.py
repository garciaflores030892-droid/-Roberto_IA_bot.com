from flask import Flask, request, jsonify, render_template_string
import requests, os, datetime

app = Flask(__name__)
MEMORIA = "memoria_rg.txt"
# URL corregida: antes estaba cortada como "http://127.0.0"
OLLAMA_URL = "http://127.0.0.1:11434/api/generate"

HTML = """
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>RG IA</title>
<style>
  * { box-sizing: border-box; }
  body { background: #0b0b0e; color: #f4f4f6; font-family: system-ui, -apple-system, sans-serif; margin: 0; display: flex; flex-direction: column; height: 100dvh; }
  header { background: #14141a; padding: 16px; text-align: center; font-weight: bold; font-size: 1.15rem; border-bottom: 1px solid #262630; display: flex; justify-content: center; align-items: center; gap: 8px; }
  .dot { width: 10px; height: 10px; background: #22c55e; border-radius: 50%; display: inline-block; }
  #chat { flex: 1; overflow-y: auto; padding: 16px; display: flex; flex-direction: column; gap: 12px; }
  .msg { max-width: 82%; padding: 12px 16px; border-radius: 18px; line-height: 1.45; font-size: 15px; word-wrap: break-word; }
  .user { background: #2563eb; color: #fff; align-self: flex-end; border-bottom-right-radius: 4px; }
  .rg { background: #1c1c24; color: #e4e4e7; align-self: flex-start; border: 1px solid #2e2e3a; border-bottom-left-radius: 4px; }
  form { display: flex; padding: 12px; background: #14141a; border-top: 1px solid #262630; gap: 8px; }
  input { flex: 1; padding: 12px 16px; border-radius: 24px; border: 1px solid #2e2e3a; background: #1f1f28; color: #fff; font-size: 16px; outline: none; }
  button { padding: 12px 20px; border-radius: 24px; border: none; background: #2563eb; color: #fff; font-weight: bold; font-size: 15px; cursor: pointer; }
  button:disabled { opacity: 0.5; }
</style>
</head>
<body>
<header><span class="dot"></span> RG &mdash; IA Privada</header>
<div id="chat"><div class="msg rg">Qu&eacute; onda compa, soy RG. Dime qu&eacute; ocupas.</div></div>
<form id="form">
  <input id="input" placeholder="Preg&uacute;ntale algo a RG..." autocomplete="off" required />
  <button id="btn" type="submit">Enviar</button>
</form>
<script>
  const form = document.getElementById('form');
  const input = document.getElementById('input');
  const btn = document.getElementById('btn');
  const chat = document.getElementById('chat');

  function add(text, cls) {
    const d = document.createElement('div');
    d.className = 'msg ' + cls;
    d.textContent = text;
    chat.appendChild(d);
    chat.scrollTop = chat.scrollHeight;
    return d;
  }

  form.onsubmit = async (e) => {
    e.preventDefault();
    const txt = input.value.trim();
    if (!txt) return;
    add(txt, 'user');
    input.value = '';
    btn.disabled = true;
    const pensando = add('Pensando...', 'rg');
    try {
      const r = await fetch('/chat', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({msg: txt})
      });
      const data = await r.json();
      pensando.textContent = data.reply;
    } catch (err) {
      pensando.textContent = 'Error de conexi\u00f3n con Ollama, compa.';
    }
    btn.disabled = false;
  };
</script>
</body>
</html>
"""

@app.route("/")
def home():
    return render_template_string(HTML)

@app.route("/chat", methods=["POST"])
def chat():
    msg = request.json.get("msg", "")
    historial = ""
    if os.path.exists(MEMORIA):
        with open(MEMORIA, "r", encoding="utf-8") as f:
            historial = f.read()[-1500:]
    prompt = f"Recuerdos recientes:\n{historial}\n\nRoberto: {msg}\nRG:"
    try:
        r = requests.post(OLLAMA_URL, json={"model": "rg", "prompt": prompt, "stream": False}, timeout=180)
        respuesta = r.json().get("response", "No pude procesar eso, compa.")
    except Exception:
        respuesta = "Ollama no me contest\u00f3, compa. Revisa que siga prendido con 'ollama serve'."
    fecha = datetime.datetime.now().strftime("%d/%m/%Y %H:%M")
    with open(MEMORIA, "a", encoding="utf-8") as f:
        f.write(f"[{fecha}] Roberto: {msg}\n[{fecha}] RG: {respuesta}\n")
    return jsonify({"reply": respuesta})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
